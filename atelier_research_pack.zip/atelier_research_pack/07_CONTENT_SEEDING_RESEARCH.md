# Atelier Content Seeding Research

# Research Document Context

These files are created for **Atelier / Designers Hub**, a creative-professional community platform being reworked around forum discussions, structured critique, help posts, resources, profiles, dashboards, uploads, search, reputation, settings, moderation, and future admin systems.

The purpose of these files is not to provide final answers yet. Each file clearly defines **what data must be researched**, **why it matters**, **what questions to answer**, and **what output should be produced** before implementation decisions are made.

Use these files as research briefs for ChatGPT, Codex, manual web research, competitor analysis, product planning, and implementation planning.


## Purpose

This research solves the early community problem: why should people contribute to an empty site? Atelier needs seeded content, example behavior, starter discussions, critique examples, and founder-led activity before public launch.

## Main research objective

Research how to make Atelier feel alive, useful, and worth contributing to even before it has a large user base.

## Data to research

### 1. Empty community problem

Research why new communities fail:

- No visible activity.
- No reason to post first.
- No examples of expected quality.
- Too many empty categories.
- No founder presence.
- No clear first action.
- No response guarantee.
- No identity or ritual.

Collect data on:

- What makes an early community feel dead.
- What makes an early community feel curated.
- How founders should seed conversations.
- How much content is needed before inviting users.

### 2. Starter discussion content

Research discussion topics that creative professionals care about.

Create data sets for:

- 50 starter discussion ideas.
- 20 beginner discussion prompts.
- 20 advanced/professional discussion prompts.
- 20 discipline-specific discussion prompts.
- 10 controversial but respectful design debate prompts.
- 10 process/workflow prompts.

Examples to research:

- Design process.
- Client handling.
- Portfolio decisions.
- Typography choices.
- Tool debates.
- Career growth.
- Creative blocks.
- Design ethics.
- Critique culture.

### 3. Starter critique examples

Research and prepare:

- 30 critique prompt examples.
- 10 visual critique sample posts.
- 10 beginner critique requests.
- 10 advanced critique requests.
- 10 examples of high-quality critique comments.
- 10 examples of weak critique comments to avoid.

Data to collect:

- What context a critique post includes.
- What image/project description looks like.
- How feedback should be requested.
- How comments should respond.

### 4. Help/Q&A seed content

Research common beginner and intermediate questions.

Create:

- 30 beginner help questions.
- 20 UI/UX help questions.
- 20 branding help questions.
- 20 typography/layout questions.
- 20 portfolio/career questions.
- 10 accepted-solution examples.

Data to collect:

- Questions that are specific enough to answer.
- Questions that are too vague.
- How to rewrite vague questions into better ones.

### 5. Resource seed content

Research resource-sharing posts.

Create:

- 30 useful design resources.
- 20 tool/resource discussion prompts.
- 10 resource review examples.
- 10 curated lists.
- 10 “how I use this tool” posts.

Data to collect:

- What resource metadata is needed.
- How to avoid link dumping.
- How to encourage explanation.

### 6. Founder-led posts

Research founder/community-seed content.

Create:

- 10 founder introduction posts.
- 10 product vision posts.
- 10 community standard posts.
- 10 critique example posts.
- 10 weekly challenge posts.
- 10 “what we are building” update posts.

Data to collect:

- How founder voice should sound.
- How transparent the founder should be.
- How to ask for participation without begging.

### 7. Early beta strategy

Research:

- Invite-only beta.
- Small cohort launch.
- Discipline-specific invites.
- Founder responding to every post.
- Expert seeding.
- Private launch before public launch.
- Launch with 3-5 active categories, not 20 empty ones.

Data to collect:

- How many seed posts are needed.
- How many early users are needed.
- Which discipline to start with.
- How to measure early engagement.

## Questions this research must answer

1. How much seed content is needed before launch?
2. Which categories should be active first?
3. What starter posts should exist?
4. What example critique posts should teach users?
5. How should the founder participate?
6. How do we avoid empty discipline hubs?
7. Should launch be invite-only?
8. What community rituals should start first?
9. How can empty states guide contribution?
10. What is the first 30-day content plan?

## Sources and references to research

Research:

- Community seeding strategies.
- Founder-led community launches.
- Indie Hackers/Product Hunt community starts.
- Subreddit growth patterns.
- Discord server launch strategies.
- Design challenge communities.
- Critique communities.

Look for:

- Starter post formats.
- Challenge formats.
- Weekly rituals.
- Launch calendars.
- Founder activity examples.

## Expected output

After research, produce:

- 30-day content seeding calendar.
- Starter discussion bank.
- Critique example bank.
- Help question bank.
- Resource post bank.
- Founder post templates.
- Launch category strategy.
- Empty-state content strategy.

## Codex usage

Use this research to create or update:

```txt
/docs/launch/CONTENT_SEEDING_PLAN.md
/docs/content/STARTER_POST_BANK.md
/docs/content/CRITIQUE_EXAMPLE_BANK.md
```

---

## Research Findings

Use this section to paste actual research notes, screenshots, references, observations, and examples.

### Findings

- 

### Strong references

- 

### Weak references / avoid

- 

### Final decisions from this research

- 

### Open questions

-
