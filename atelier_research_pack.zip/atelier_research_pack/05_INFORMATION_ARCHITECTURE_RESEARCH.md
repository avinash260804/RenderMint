# Atelier Information Architecture Research

# Research Document Context

These files are created for **Atelier / Designers Hub**, a creative-professional community platform being reworked around forum discussions, structured critique, help posts, resources, profiles, dashboards, uploads, search, reputation, settings, moderation, and future admin systems.

The purpose of these files is not to provide final answers yet. Each file clearly defines **what data must be researched**, **why it matters**, **what questions to answer**, and **what output should be produced** before implementation decisions are made.

Use these files as research briefs for ChatGPT, Codex, manual web research, competitor analysis, product planning, and implementation planning.


## Purpose

This research defines how the platform is organized: routes, navigation, zones, page hierarchy, user flows, and relationships between public, community, critique, profile, dashboard, settings, and admin areas.

## Main research objective

Research the clearest structure for Atelier so users understand where to browse, where to critique, where to ask for help, where to manage identity, and where admins/moderators control quality.

## Data to research

### 1. Platform zones

Research the purpose and structure of each zone:

#### Public identity zone

- Home.
- About.
- Public discipline previews.
- Featured posts/critiques.
- Login/signup.

Data to research:

- What should non-users see?
- What should be public for SEO?
- What should require login?
- What message convinces people to join?

#### Community browsing zone

- Explore feed.
- Latest/trending/unanswered/solved.
- Discipline hubs.
- Tags.
- Search.

Data to research:

- What filters are useful?
- How should post types be separated?
- Should critique have its own main nav item?
- How should users discover relevant posts?

#### Critique zone

- Critique feed.
- Critique post page.
- Create critique flow.
- Revision support later.

Data to research:

- Should critique be a separate space or post type inside forum?
- What navigation does critique need?
- How should critique posts be filtered?

#### Creation zone

- Choose post type.
- Create discussion.
- Create critique.
- Ask for help.
- Share resource.
- Preview/publish.

Data to research:

- Should creation be step-based?
- Which fields are required by post type?
- How can form design improve post quality?

#### User identity zone

- Public profile.
- Contributions.
- Saved posts.
- Reputation.
- Portfolio-like sections.

Data to research:

- What public identity matters for creatives?
- What should be visible to everyone?
- What should be private?

#### Dashboard zone

- My posts.
- My critiques.
- Replies.
- Saved items.
- Drafts.
- Recommended actions.

Data to research:

- What should returning users see first?
- How can dashboard encourage contribution?
- What should be avoided?

#### Settings zone

- Profile settings.
- Account settings.
- Notification preferences.
- Privacy settings.
- Appearance/theme.

Data to research:

- Which settings are needed now?
- Which settings are placeholders for later?
- How should settings be grouped?

#### Admin/moderation zone

- Reports.
- Posts moderation.
- User management.
- Discipline/category management.
- Basic platform stats.
- Admin-only access.

Data to research:

- What must exist for launch?
- What should be postponed?
- How to avoid overbuilding admin?

### 2. Route research

Research a route map for Atelier.

Potential routes:

```txt
/
/about
/explore
/explore?type=discussion
/critiques
/disciplines
/disciplines/[slug]
/tags/[slug]
/search
/thread/[slug]
/create
/create/discussion
/create/critique
/create/help
/create/resource
/profile/[username]
/dashboard
/dashboard/posts
/dashboard/critiques
/dashboard/saved
/settings
/settings/profile
/settings/account
/settings/privacy
/admin
/admin/reports
/admin/posts
/admin/users
/admin/disciplines
```

Research:

- Which routes should exist at launch?
- Which routes are future placeholders?
- Which should be protected?
- Which should be public?
- Which need SSR/SEO?

### 3. Navigation research

Research navigation systems:

- Top nav.
- Sidebar.
- Mobile nav.
- User menu.
- Create button.
- Search entry.
- Breadcrumbs.
- Secondary tabs.
- Admin navigation.

Data to collect:

- What should always be visible?
- What should be hidden in menus?
- How should new users navigate?
- How should power users navigate?

### 4. User flow research

Research core flows:

- Visitor lands → understands Atelier → signs up.
- New user signs up → chooses discipline → creates profile → takes first action.
- User browses → filters posts → opens thread → comments/votes.
- User creates critique → uploads work → receives feedback → revises.
- User asks help → receives answer → marks solution.
- User edits profile/settings.
- Admin reviews report → moderates content.

For each flow, research:

- Entry point.
- Required steps.
- Friction points.
- Empty states.
- Success states.
- Error states.

### 5. Content hierarchy research

Research what information matters most on different pages.

Examples:

- Feed card: title, type, discipline, author, replies, votes, status, preview, tags, time.
- Critique card: image preview, title, requested feedback, discipline, stage, comments, revision status.
- Profile: name, discipline, bio, work/contributions, reputation, badges, activity.
- Dashboard: pending replies, drafts, saved items, recommended action.

## Questions this research must answer

1. What are the main zones of Atelier?
2. What should the main navigation contain?
3. Should critique have a separate nav item?
4. What routes are needed for launch?
5. What routes should wait?
6. What pages are public vs protected?
7. How should settings and admin be added without overbuilding?
8. What user flows must be seamless?
9. What information appears on each card/page?
10. What structure should Codex implement first?

## Sources and references to research

Research:

- Community platform route structures.
- Forum navigation.
- Portfolio profile navigation.
- Dashboard IA.
- Admin panel IA.
- Settings page structures.
- Search/filter UX.
- Mobile nav patterns.

Look for:

- Sitemap examples.
- Navigation screenshots.
- Feed layouts.
- User flow maps.
- Settings/admin structures.

## Expected output

After research, produce:

- Full sitemap.
- Route priority list.
- Navigation model.
- Public/protected route list.
- User flow maps.
- Page hierarchy model.
- Settings/admin minimal structure.
- Implementation order.

## Codex usage

Use this research to create or update:

```txt
/docs/ux/INFORMATION_ARCHITECTURE.md
/docs/ux/ROUTE_MAP.md
/docs/ux/USER_FLOWS.md
```

---

## Research Findings

Use this section to paste actual research notes, screenshots, references, observations, and examples.

### Findings

- 

### Strong references

- 

### Weak references / avoid

- 

### Final decisions from this research

- 

### Open questions

-
