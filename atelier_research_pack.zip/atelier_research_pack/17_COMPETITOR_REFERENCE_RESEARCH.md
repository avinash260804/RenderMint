# Atelier Competitor and Reference Research

# Research Document Context

These files are created for **Atelier / Designers Hub**, a creative-professional community platform being reworked around forum discussions, structured critique, help posts, resources, profiles, dashboards, uploads, search, reputation, settings, moderation, and future admin systems.

The purpose of these files is not to provide final answers yet. Each file clearly defines **what data must be researched**, **why it matters**, **what questions to answer**, and **what output should be produced** before implementation decisions are made.

Use these files as research briefs for ChatGPT, Codex, manual web research, competitor analysis, product planning, and implementation planning.


## Purpose

This research gathers references and competitors so Atelier can learn from existing platforms without copying them blindly.

## Main research objective

Research platforms, communities, tools, and products that overlap with Atelier's goals, then identify patterns to borrow, improve, avoid, or reject.

## Data to research

### 1. Direct and indirect competitors

Research platforms in these categories:

#### Design portfolio platforms

- Behance-like platforms.
- Dribbble-like platforms.
- Portfolio builders.
- Creative profile pages.

Data to collect:

- Profile structure.
- Work display.
- Feedback/comment behavior.
- Discovery model.
- Weaknesses for critique/community.

#### Forum/community platforms

- Reddit-style communities.
- Discourse forums.
- Indie Hackers-style communities.
- Dev.to-style communities.
- Forem-style platforms.

Data to collect:

- Feed structure.
- Post metadata.
- Comments.
- Voting.
- Moderation.
- Tag/category model.

#### Q&A platforms

- Stack Overflow-style systems.
- Product support communities.
- Help forums.

Data to collect:

- Accepted solution model.
- Reputation model.
- Question quality rules.
- Duplicate handling.
- Voting rules.

#### Critique platforms and communities

- Design critique subreddits.
- Portfolio review communities.
- Studio/school critique examples.
- Image review tools.

Data to collect:

- Critique post structure.
- Feedback quality.
- Visual review UI.
- Revision handling.
- Community rules.

#### Creative learning communities

- Course communities.
- Cohort-based learning spaces.
- Challenge communities.
- Mentor communities.

Data to collect:

- Onboarding.
- Assignments/challenges.
- Feedback loops.
- Progress systems.
- Community rituals.

### 2. Reference analysis framework

For every reference, collect:

- Name.
- URL.
- Category.
- Main user type.
- What it does well.
- What it does poorly.
- UI strengths.
- UI weaknesses.
- Community strengths.
- Community weaknesses.
- Monetization model.
- Onboarding model.
- Profile model.
- Post/comment model.
- Moderation model.
- What Atelier can learn.
- What Atelier must avoid copying.

### 3. UI pattern references

Research patterns for:

- Landing page.
- Explore/feed page.
- Post cards.
- Critique cards.
- Thread pages.
- Comment systems.
- Profile pages.
- Dashboard pages.
- Settings pages.
- Admin pages.
- Empty states.
- Mobile navigation.

Data to collect:

- Screenshots.
- Layout notes.
- Component notes.
- What works for Atelier.
- What does not fit.

### 4. Community behavior references

Research:

- How users interact.
- Quality of discussion.
- Critique depth.
- Spam issues.
- Reputation incentives.
- Beginner friendliness.
- Expert participation.

Data to collect:

- What behavior is encouraged by design.
- What behavior is accidentally encouraged.
- What Atelier should intentionally design for.

### 5. Differentiation research

Research how Atelier can stand apart.

Possible differentiation:

- Structured critique, not random comments.
- Creative identity plus community contribution.
- Discipline-specific hubs.
- Beginner-to-expert pathway.
- Reputation for helpful critique.
- Revision/improvement history.
- Premium creative UI.
- Safer, clearer community standards.

Data to collect:

- Which differentiation is strongest.
- Which differentiation is believable.
- Which differentiation requires too much build effort now.

## Questions this research must answer

1. Who are Atelier's direct competitors?
2. Who are indirect references?
3. What patterns should Atelier borrow?
4. What patterns should Atelier avoid?
5. What does no existing platform do well?
6. How can Atelier differentiate clearly?
7. What UI references best match the brand?
8. What community references best match the vision?
9. What critique references are most useful?
10. What should become the reference board for Codex?

## Sources and references to research

Research:

- Behance.
- Dribbble.
- Reddit design communities.
- Stack Overflow.
- Discourse communities.
- Indie Hackers.
- Dev.to/Forem style communities.
- Product Hunt.
- Design critique communities.
- Portfolio review communities.
- Creative learning platforms.

Look for:

- Screenshots.
- User flows.
- Community rules.
- Profile layouts.
- Feed cards.
- Critique structures.
- Reputation systems.
- Landing page messaging.

## Expected output

After research, produce:

- Competitor matrix.
- Reference board.
- Borrow/improve/avoid list.
- Differentiation map.
- UI pattern library.
- Community pattern library.
- Codex reference guide.

## Codex usage

Use this research to create or update:

```txt
/docs/research/COMPETITOR_MATRIX.md
/docs/design/VISUAL_REFERENCE_BOARD.md
/docs/product/DIFFERENTIATION_MAP.md
/docs/design/UI_PATTERN_LIBRARY.md
```

---

## Research Findings

Use this section to paste actual research notes, screenshots, references, observations, and examples.

### Findings

- 

### Strong references

- 

### Weak references / avoid

- 

### Final decisions from this research

- 

### Open questions

-
