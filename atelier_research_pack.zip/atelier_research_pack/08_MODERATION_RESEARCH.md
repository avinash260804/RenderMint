# Atelier Moderation Research

# Research Document Context

These files are created for **Atelier / Designers Hub**, a creative-professional community platform being reworked around forum discussions, structured critique, help posts, resources, profiles, dashboards, uploads, search, reputation, settings, moderation, and future admin systems.

The purpose of these files is not to provide final answers yet. Each file clearly defines **what data must be researched**, **why it matters**, **what questions to answer**, and **what output should be produced** before implementation decisions are made.

Use these files as research briefs for ChatGPT, Codex, manual web research, competitor analysis, product planning, and implementation planning.


## Purpose

This research defines how Atelier will maintain quality, safety, and trust. Since Atelier depends on critique and professional contribution, moderation must protect users without making the platform feel hostile or overcontrolled.

## Main research objective

Research moderation systems, quality rules, reporting flows, admin tools, anti-spam behavior, and community standards for a creative-professional platform.

## Data to research

### 1. Community rules

Research rules for:

- Respectful critique.
- No harassment.
- No plagiarism.
- No spam.
- No low-effort posts.
- No fake portfolios.
- No offensive content.
- No stolen work.
- No self-promotion spam.
- No misleading resources.

Data to collect:

- What rules should be public?
- How strict should rules be?
- What needs warning vs removal?
- What should lead to account restriction?

### 2. Low-effort post definition

Research what makes a post low quality.

Examples:

- “Thoughts?” with no context.
- Image upload without project goal.
- Vague help request.
- Duplicate content.
- Link without explanation.
- Showcase disguised as critique.
- AI-generated spam.

Data to collect:

- How to guide users before posting.
- What minimum fields should be required.
- What posts should be blocked by form design.
- What posts need moderator review.

### 3. Bad critique definition

Research what critique should not allow:

- Personal insults.
- Vague negativity.
- Non-actionable comments.
- Harsh tone without explanation.
- Off-topic arguments.
- Unwanted redesign takeover.
- Discrimination or harassment.
- Spammy self-promotion.

Data to collect:

- How to define bad critique.
- How to educate users.
- How to report comments.
- What critique should be hidden or removed.

### 4. Report system

Research report categories:

- Spam.
- Harassment.
- Stolen work.
- Copyright/IP concern.
- Low-effort post.
- Misleading resource.
- Offensive content.
- Personal information exposure.
- Wrong category/tag.
- Other.

Data to collect:

- What report fields are needed.
- Should reports allow notes?
- What happens after report submission?
- Should users receive status updates?
- How should false reports be handled?

### 5. Admin/moderation tools

Research minimal admin tools for launch:

- View reported posts.
- View reported comments.
- Hide/unhide content.
- Delete content.
- Lock thread.
- Change post category/type.
- Warn user.
- Suspend user later.
- View user activity.
- Manage disciplines/tags.

Data to collect:

- What admin screens are required now.
- What can wait.
- How to protect admin routes.
- What actions need confirmation.
- What actions need audit logs.

### 6. Moderation workflow

Research workflows:

- User reports content.
- Admin reviews report.
- Admin takes action.
- User is notified if needed.
- Action is logged.
- Content status changes.

Data to collect:

- What statuses content can have.
- What statuses reports can have.
- How many moderator roles exist.
- Whether soft delete is needed.
- Whether appeals are needed now or later.

### 7. Spam and abuse prevention

Research:

- Rate limits.
- Duplicate post detection.
- Link limits.
- New account limits.
- Reputation farming detection.
- Self-voting prevention.
- Multiple account abuse.
- Upload abuse.

Data to collect:

- What can be automated.
- What should be moderator-reviewed.
- What can wait until scale.

## Questions this research must answer

1. What are Atelier's community rules?
2. What is a low-effort post?
3. What is bad critique?
4. What report categories are needed?
5. What admin tools are required for launch?
6. What moderation actions should exist?
7. What should be soft-deleted vs permanently removed?
8. How should stolen work be handled?
9. How should spam be prevented?
10. What moderation features should wait?

## Sources and references to research

Research:

- Community guidelines.
- Design critique communities.
- Reddit moderation.
- Stack Overflow moderation.
- Discord moderation.
- Portfolio site policies.
- User-generated content policies.
- Trust and safety best practices.

Look for:

- Report flows.
- Moderator dashboards.
- Community rules pages.
- Low-effort rules.
- Critique guidelines.
- Spam prevention systems.

## Expected output

After research, produce:

- Community rules.
- Critique guidelines.
- Low-effort post policy.
- Report categories.
- Admin tool requirements.
- Moderation workflow.
- Abuse prevention strategy.
- Launch moderation checklist.

## Codex usage

Use this research to create or update:

```txt
/docs/moderation/MODERATION_POLICY.md
/docs/moderation/REPORT_SYSTEM_REQUIREMENTS.md
/docs/moderation/ADMIN_REQUIREMENTS.md
```

---

## Research Findings

Use this section to paste actual research notes, screenshots, references, observations, and examples.

### Findings

- 

### Strong references

- 

### Weak references / avoid

- 

### Final decisions from this research

- 

### Open questions

-
