# Atelier QA and Testing Research

# Research Document Context

These files are created for **Atelier / Designers Hub**, a creative-professional community platform being reworked around forum discussions, structured critique, help posts, resources, profiles, dashboards, uploads, search, reputation, settings, moderation, and future admin systems.

The purpose of these files is not to provide final answers yet. Each file clearly defines **what data must be researched**, **why it matters**, **what questions to answer**, and **what output should be produced** before implementation decisions are made.

Use these files as research briefs for ChatGPT, Codex, manual web research, competitor analysis, product planning, and implementation planning.


## Purpose

This research defines how to test Atelier before and after the UI rework. Since many flows depend on auth, uploads, posts, comments, votes, profiles, and admin, testing must protect existing functionality while the brand UI changes.

## Main research objective

Research manual QA flows, automated testing, accessibility testing, responsive testing, security testing, and release checklists for the Atelier platform.

## Data to research

### 1. Core user journey tests

Research tests for:

- Visitor landing page.
- Signup.
- Login.
- Auth callback.
- Onboarding.
- Profile setup.
- Explore feed.
- Discipline hub.
- Search.
- Create discussion.
- Create critique.
- Upload image.
- Create help post.
- Share resource.
- Open thread.
- Comment.
- Vote.
- Accept solution.
- Save/bookmark.
- Edit profile.
- Dashboard.
- Settings.
- Logout.

Data to collect:

- Expected result for each flow.
- Edge cases.
- Error states.
- Mobile behavior.
- Auth requirements.

### 2. Admin and moderation tests

Research tests for:

- Admin route protection.
- Non-admin blocked from admin pages.
- View reported content.
- Hide/delete content.
- User management.
- Discipline management.
- Moderation action logging.

Data to collect:

- Which admin flows exist now.
- Which are future.
- What must be tested before launch.

### 3. UI regression testing

Research how to test UI rework safely:

- Screenshot testing.
- Visual diffing.
- Component review.
- Responsive breakpoints.
- Dark/light mode if used.
- Empty states.
- Loading states.
- Error states.

Data to collect:

- Pages most likely to break.
- Components used repeatedly.
- Layout breakpoints.
- Critical visual states.

### 4. Accessibility testing

Research:

- Keyboard navigation.
- Focus states.
- Color contrast.
- Form labels.
- Error messages.
- ARIA usage.
- Dialog accessibility.
- Dropdown/menu accessibility.
- Screen reader basics.

Data to collect:

- Accessibility checklist.
- Tools to use.
- Components needing attention.

### 5. Responsive testing

Research device sizes:

- Mobile small.
- Mobile large.
- Tablet.
- Laptop.
- Desktop.
- Wide screens.

Data to collect:

- How navigation changes.
- How cards stack.
- How critique images display.
- How forms behave.
- How dashboard/admin tables respond.

### 6. Security testing

Research tests for:

- Auth bypass.
- Cross-user edit/delete.
- XSS payloads.
- Unsafe uploads.
- Rate limits.
- Secrets exposure.
- Admin route access.
- Logout invalidation.

Data to collect:

- Manual test cases.
- Automated test cases.
- Launch blockers.

### 7. Performance testing

Research:

- Feed load time.
- Thread page load time.
- Search response time.
- Upload time.
- Image loading.
- N+1 query detection.
- Bundle size.

Data to collect:

- Performance budget.
- Slow pages.
- Slow queries.
- Image optimization needs.

### 8. Testing tools

Research tools:

- Playwright.
- Vitest/Jest.
- React Testing Library.
- Lighthouse.
- Axe accessibility testing.
- Browser devtools.
- TesterArmy or similar QA tools later.
- GitHub Actions testing.

Data to collect:

- Which tools fit current stage.
- Which are too early.
- What can be manual for now.
- What should be automated.

## Questions this research must answer

1. What flows must be tested before launch?
2. What flows must be tested after every UI rework?
3. What should be automated first?
4. What can remain manual for now?
5. What are the critical responsive breakpoints?
6. What accessibility rules must be followed?
7. What security tests are launch blockers?
8. What performance budget should be used?
9. What QA tools should be adopted?
10. What is the release checklist?

## Sources and references to research

Research:

- QA checklists for web apps.
- Playwright examples.
- Next.js testing strategies.
- Accessibility testing tools.
- Responsive QA checklists.
- Security test cases.
- Community platform testing flows.

Look for:

- Test plans.
- E2E examples.
- Manual QA templates.
- Accessibility checklists.
- Release checklists.

## Expected output

After research, produce:

- Manual QA checklist.
- E2E test plan.
- Accessibility checklist.
- Responsive test matrix.
- Security test list.
- Performance test list.
- Release checklist.

## Codex usage

Use this research to create or update:

```txt
/docs/qa/MANUAL_QA_CHECKLIST.md
/docs/qa/E2E_TEST_PLAN.md
/docs/qa/RESPONSIVE_TEST_MATRIX.md
/docs/qa/RELEASE_CHECKLIST.md
```

---

## Research Findings

Use this section to paste actual research notes, screenshots, references, observations, and examples.

### Findings

- 

### Strong references

- 

### Weak references / avoid

- 

### Final decisions from this research

- 

### Open questions

-
