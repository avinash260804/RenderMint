# Atelier Privacy and Legal Research

# Research Document Context

These files are created for **Atelier / Designers Hub**, a creative-professional community platform being reworked around forum discussions, structured critique, help posts, resources, profiles, dashboards, uploads, search, reputation, settings, moderation, and future admin systems.

The purpose of these files is not to provide final answers yet. Each file clearly defines **what data must be researched**, **why it matters**, **what questions to answer**, and **what output should be produced** before implementation decisions are made.

Use these files as research briefs for ChatGPT, Codex, manual web research, competitor analysis, product planning, and implementation planning.


## Purpose

This research defines the legal and privacy foundations needed before Atelier becomes public. Since Atelier will collect accounts, profiles, posts, comments, uploads, votes, and possibly analytics, user trust depends on clear policies.

## Main research objective

Research privacy policy, terms of service, user-generated content ownership, account deletion, data export, cookie/tracking disclosure, copyright/IP issues, and community content rights.

## Data to research

### 1. Privacy policy requirements

Research what data Atelier collects:

- Account email.
- Display name.
- Username.
- Avatar.
- Bio.
- Discipline.
- Posts.
- Comments.
- Votes.
- Uploads.
- Saved items.
- Search/activity logs if stored.
- IP/device/security logs.
- Analytics data if used.

Data to collect:

- What data is collected.
- Why it is collected.
- Where it is stored.
- Who can access it.
- How long it is retained.
- How users can delete/export it.

### 2. Terms of service

Research terms needed for:

- User account rules.
- Acceptable use.
- User-generated content.
- Moderation rights.
- Account suspension.
- Community behavior.
- Platform availability.
- Disclaimers.
- Limitation of liability.

Data to collect:

- What rules users agree to.
- What Atelier can remove.
- What user actions can lead to restriction.
- What responsibilities users have.

### 3. User-generated content ownership

Research:

- Who owns uploaded design work.
- What license Atelier needs to display user content.
- Whether Atelier can feature user work.
- Whether users can delete their work.
- Whether deleted content remains in backups.
- Whether comments/critiques remain after post deletion.

Data to collect:

- Ownership language.
- Display license language.
- Feature/promote permission.
- Deletion rights.
- Content backup retention.

### 4. Copyright and IP policy

Research:

- Stolen work reports.
- Copyright takedown process.
- Plagiarism handling.
- Use of references/inspiration.
- External resource links.
- User responsibility for uploads.

Data to collect:

- Report category for stolen work.
- Evidence required.
- Moderator process.
- Repeat offender policy.

### 5. Account deletion and data export

Research:

- Account deletion flow.
- What gets deleted.
- What gets anonymized.
- What remains for community integrity.
- Data export format.
- How long deletion takes.

Data to collect:

- Technical requirements.
- UX flow.
- Policy language.
- Database implications.

### 6. Cookie and tracking disclosure

Research:

- Whether analytics are used.
- Cookie consent requirements.
- Essential vs non-essential cookies.
- Auth cookies.
- Tracking pixels if any.

Data to collect:

- What cookies exist.
- Whether consent banner is needed.
- How users can opt out.

### 7. Age and safety policy

Research:

- Whether minors can use the platform.
- Whether age restrictions are needed.
- How to handle harmful content.
- How to handle personal data exposure.

Data to collect:

- Minimum age recommendation.
- Safety reporting.
- Moderator response.

## Questions this research must answer

1. What personal data does Atelier collect?
2. What should the privacy policy say?
3. What should the terms of service say?
4. Who owns uploaded work?
5. Can Atelier feature user work?
6. Can users delete posts and uploads?
7. How is stolen work handled?
8. Is data export needed before launch?
9. Is account deletion needed before launch?
10. Is cookie consent needed?

## Sources and references to research

Research:

- Privacy policies of community platforms.
- Terms of service of portfolio/design platforms.
- User-generated content policies.
- Copyright policies.
- Account deletion practices.
- Data export practices.
- Cookie consent laws relevant to target users.

Look for:

- Plain-language policy examples.
- UGC ownership clauses.
- Community moderation clauses.
- Copyright takedown flows.
- Privacy dashboards.

## Expected output

After research, produce:

- Privacy policy draft.
- Terms of service draft.
- UGC ownership policy.
- Copyright/stolen work policy.
- Account deletion requirements.
- Data export requirements.
- Cookie/tracking decision.
- Legal launch checklist.

## Codex usage

Use this research to create or update:

```txt
/docs/legal/PRIVACY_POLICY_DRAFT.md
/docs/legal/TERMS_OF_SERVICE_DRAFT.md
/docs/legal/UGC_CONTENT_POLICY.md
/docs/legal/ACCOUNT_DELETION_REQUIREMENTS.md
```

---

## Research Findings

Use this section to paste actual research notes, screenshots, references, observations, and examples.

### Findings

- 

### Strong references

- 

### Weak references / avoid

- 

### Final decisions from this research

- 

### Open questions

-
